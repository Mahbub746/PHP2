<?php
include("db.php");
if(isset($_REQUEST['id'])){
	$id=$_REQUEST['id'];
}
if(isset($_REQUEST['del_id'])){
	$del_id=$_REQUEST['del_id'];
	if($obj->Delete("students","id=$del_id")){
		header("location:read.php?status=delete");
	}
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
  	<div class="container">
  		Do you want to Delete?
  		<a class="btn btn-danger" href="delete.php?del_id=<?=$id;?>">Yes</a>&nbsp;&nbsp;<a class="btn btn-info" href="read.php">No</a>
</div>
</form>
</div>
  </body>
</html>
<?php
include("db.php");
/*echo "<pre>";
print_r($_REQUEST);*/
/*$array=["a"=>"America","b"=>"Bangladesh"];
extract($array);
echo $a;*/
if(isset($_REQUEST['submit'])){
	extract($_REQUEST);
	$hobby1=$hobby1??"";
	$hobby2=$hobby2??"";
	if($obj->Create("students","name='$name',mobile='$mobile',address='$address',gender='$gender',hobby='$hobby1,$hobby2',country='$country'")){
		echo "Insert Success";
	}
	else{
		echo "Insert Fail!";
	}
}
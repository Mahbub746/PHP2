<?php
class Db{
	private $conn;
	public function __construct($host,$user,$pass,$db){
		$this->conn=new mysqli($host,$user,$pass,$db);
	}

	public function Create($table,$cols){
		$sql="INSERT INTO $table SET $cols";
		$this->conn->query($sql);
		if($this->conn->affected_rows>0){
			return true;
		}
		return false;
	}

	public function Read($table,$cols){
		$sql="SELECT $cols FROM $table";
		$result=$this->conn->query($sql);

		if($result->num_rows>0){
			return $result->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}

	public function getByCondition($table,$cols,$condition){
		$sql="SELECT $cols FROM $table WHERE $condition";
		$result=$this->conn->query($sql);

		if($result->num_rows>0){
			return $result->fetch_assoc();
		}
		return false;
	}

	public function Update($table,$cols,$condition){
		$sql="UPDATE $table SET $cols WHERE $condition";
		$this->conn->query($sql);
		if($this->conn->affected_rows>0){
			return true;
		}
		return false;
	}
	public function Delete($table,$condition){
		$sql="DELETE FROM $table WHERE $condition";
		$this->conn->query($sql);
		if($this->conn->affected_rows>0){
			return true;
		}
		return false;
	}
}

$obj=new Db("localhost","root","","mydb");
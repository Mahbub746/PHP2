<?php
include("db.php");
$students=$obj->Read("students","*");
$a="America";
/*echo "<pre>";
  print_r($students);
echo "</pre>";*/
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Read</title>
  </head>
  <body>
    <div class="container">
      <?php
        if(isset($_REQUEST['status'])){
          echo "<span class=\"text-success\">Delete Success</span>";
        }
      ?>
    <table class="table table-bordered table-hover table-condensed table-stripped table-responsive">
     
        <?php
        echo "<tr>";
          foreach($students[0] as $col=>$val){
            echo "<th>".ucfirst($col)."</th>";
          }
        echo "<th>Action</th>";
        echo "</tr>";
        $i=1;
          foreach($students as $row){
            echo "<tr>";
              foreach($row as $val){
                echo "<td>$val</td>";
                $i++;
              }
            echo "<td><a class=\"btn btn-info\" href=\"update.php?id=$row[id]\">Edit </a>&nbsp;&nbsp;<a class=\"btn btn-danger\" href=\"delete.php?id=$row[id]\">Delete</a></td>";
            echo "</tr>";
          }
        ?>
      <tr>
        <td class="text-center" colspan="<?=$i;?>"><a href="create.php" class="btn btn-primary">Add New Student</a></td>
      </tr>
    </table>
</div>
  </body>
</html>
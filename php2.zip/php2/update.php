<?php
include("db.php");
if(isset($_REQUEST['id'])){
	$id=$_REQUEST['id'];
	extract($obj->getByCondition("students","*","id=$id"));
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
  	<div class="container">
  		<h2>Add New Student</h2>
 <form method="post" action="update_process.php">
<div class="mb-3">
  <label for="name" class="form-label h4">Name</label>
  <input type="text" name="name" value="<?=$name;?>" class="form-control" placeholder="Omar Faruk">
</div>
<div class="mb-3">
  <label for="mobile" class="form-label h4">Mobile</label>
  <input type="text" name="mobile" value="<?=$mobile;?>" class="form-control" placeholder="01XXXXXXXX">
</div>
<div class="mb-3">
  <label for="address" class="form-label h4">Address</label>
  <textarea class="form-control" rows="3" name="address" placeholder="Dhaka,Bangladesh"><?=$address;?></textarea>
</div>
<div class="mb-1">
<label for="gender" class="form-label h4">Gender:</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio"<?php if($gender=='Male'){ echo "checked";}?>  name="gender" value="Male">
  <label class="form-check-label">Male</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" <?php if($gender=='female'){ echo "checked";}?> type="radio" name="gender" value="Female">
  <label class="form-check-label">Female</label>
</div>

<!-- <div class="mt-3">
<label for="hobby" class="form-label h4">Hobby:</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" name="hobby1" type="checkbox" value="cricket">
  <label class="form-check-label">Cricket</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="checkbox" name="hobby2" value="Football">
  <label class="form-check-label">Football</label>
</div> -->
<div class="mt-3">
<label for="country" class="form-label h4">Country:</label>
</div>
<select class="form-select" name="country">
  <option value="" <?php if($country==''){ echo "selected";}?> selected>Select a Country</option>
  <option value="Bangladesh" <?php if($country=='Bangladesh'){ echo "selected";}?>>Bangladesh</option>
  <option value="India" <?php if($country=='India'){ echo "selected";}?>>India</option>
  <option value="Pakistan" <?php if($country=='Pakistan'){ echo "selected";}?>>Pakistan</option>
</select>
<div class="mt-3 text-center">
	<input type="hidden" name="id" value="<?=$id;?>">
<input type="Submit" name="submit" value="Save" class="btn btn-primary">
</div>
</form>
</div>
  </body>
</html>